# Bài tập Trainee Colombo 2018

## Frontend 2.1: Bootstrap 1

* Sử dụng draw.io vẽ lại mockup
* Sử dụng bootstrap, sass, kết hợp các thư viện js/css để hoàn thiện giao diện đầy đử của 1 sản phẩm

Người thực hiện: [ Tiến Nguyễn ](https://github.com/tiennguyen98)

## Liên kết

* [Link bài online](https://tiennguyen98.github.io/front-end2.4/)
* [Link mockup draw.io](https://drive.google.com/file/d/1HvLJNvZdIEFd5JYegih2ohxkg_bDbgqw/view)
* [Link tìm hiểu về Bootstrap 4](https://gist.github.com/tiennguyen98/ebefe06b499a551a89a64de5f71640b6)

## Kiến thức nắm được
* Biết download và sử dụng Bootstrap 4 cơ bản

## Credit
* Photoshop CS6
* SublimeText 3
* Chorme
* Git
